#include <opencv2/core.hpp>// Mat
#include <opencv2/highgui.hpp>  //imshow
#include <opencv2/imgcodecs.hpp>//imread
#include <cstdio>
#include <opencv2/imgproc.hpp>//calcHist
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <opencv2/xfeatures2d.hpp>//SiftDescriptorExtractor
#include <opencv2/features2d.hpp>
#include "main_aux.h"

#define ALLOCATION_FAILTURE "An error occurred - allocation failure\n"

#define check_malloc_null(pointer) { \
	if (pointer == NULL) { \
		printf(ALLOCATION_FAILTURE);\
		return NULL;}}


/* For Testing:
* source init.sh
* make
* valgrind --leak-check=full --track-origins=yes --show-reachable=yes ex2
*/

using namespace cv;


/*
 * Calculates the RGB channels histogram. The histogram will be stored in a
 * two dimensional array of dimensions 3XnBins . The first row is the
 * red channel histogram, the second row is the green channel histogram
 * and the third row is the blue channel histogram.
 *
 * @param str - The path of the image for which the histogram will be calculated
 * @param nBins - The number of subdivision for the intensity histogram
 * @return NULL if str is NULL or nBins <= 0 or allocation error occurred,
 *  otherwise a two dimensional array representing the histogram.
 */

int** spGetRGBHist(char* str, int nBins)
{
	if(str == NULL || nBins <= 0) {
		return NULL;
	}
	// Variables
	int **histInt;

	/// Load image
	Mat src = imread(str, CV_LOAD_IMAGE_COLOR);
	/// Separate the image
	std::vector<Mat> bgr_planes;
	split(src, bgr_planes);

	/// Set the ranges ( for B,G,R) )
	float range[] = { 0, 256 };
	const float* histRange = { range };

	/// Set the other parameters:
	int nImages = 1;

	//Output
	Mat b_hist, g_hist, r_hist;

	/// Compute the histograms:
	/// The results will be store in b_hist,g_hist,r_hist.
	/// The output type of the matrices is CV_32F (float)
	calcHist(&bgr_planes[0], nImages, 0, Mat(), b_hist, 1, &nBins, &histRange);
	calcHist(&bgr_planes[1], nImages, 0, Mat(), g_hist, 1, &nBins, &histRange);
	calcHist(&bgr_planes[2], nImages, 0, Mat(), r_hist, 1, &nBins, &histRange);

	histInt=(int **) malloc(3 * sizeof(*histInt));
	check_malloc_null(histInt);

	// Load matrix values
	for (int i = 0; i < 3; i++) {
		histInt[i] = (int *) malloc(b_hist.rows * sizeof(int));
		check_malloc_null(histInt[i]);
	}
	for (int i = 0; i <  b_hist.rows; i++) {
		histInt[0][i] = cvRound(b_hist.at<float>(i,0));
	}
	for (int i = 0; i <  g_hist.rows; i++) {
		histInt[1][i] = cvRound(g_hist.at<float>(i,0));
	}
	for (int i = 0; i <  r_hist.rows; i++) {
		histInt[2][i] = cvRound(r_hist.at<float>(i,0));
	}

	return histInt;
}


/**
 * Returns the average L2-squared distance between histA and histB. The
 * histA and histB are histograms of the RGB channels. Both histograms
 * must be in the same dimension (3 X nBins).
 * @param histA - RGB histogram of image A
 * @param histB - RGB histogram of image B
 * @return -1 if nBins <= 0 or histA/histB is null, otherwise the average L@-squared distance.
 */
double spRGBHistL2Distance(int** histA, int** histB, int nBins)
{
	if (nBins <= 0 || histA == NULL || histB == NULL) {
		return -1;
	}

	double dis = 0;
	// Loop and calculate
	for (int i = 0; i < 3 ; i++)
	{
		for (int j = 0 ; j < nBins ; j++)
		{
			double change = (double)(histA[i][j] - histB[i][j])*(double)(histA[i][j] - histB[i][j]);
			dis = dis + change;
		}
	}
	return dis;
}

/**
 * Extracts AT MOST maxNFeatures SIFT descriptors from the image given by str.
 * The result will be stored in two dimensional matrix with nFeatures
 * rows and 128 columns. Each row represents a SIFT feature corresponding
 * to some keypoint.
 *
 * @param str - A string representing the path of the image
 * @param maxNFeautres - The max number of features features to retain
 * @param nFeatures - A pointer in which the actual number of features retained
 * will be stored.
 * @return NULL in case of:
 * 		   - str is NULL
 * 		   - the image given by str didn't open
 * 		   - nFeatures is NULL
 * 		   - maxNFeatures <= 0
 * 		   - Memory allocation failure
 * 		   otherwise, the total number of features retained will be stored in
 * 		   nFeatures, and the actual features will be returned.
 */
double** spGetSiftDescriptors(char* str, int maxNFeatures, int *nFeatures)
{
	if (str == NULL || nFeatures == NULL || maxNFeatures <= 0) {
		return NULL;
	}

	// Variables
	int resultSize;
	double ** descriptors;

	//Loading image
	Mat src;
	src = imread(str, CV_LOAD_IMAGE_GRAYSCALE);

	//Key points will be stored in kp1;
	std::vector<KeyPoint> kp1;
	//Feature values will be stored in ds1;
	Mat ds1;
	//Creating  a Sift Descriptor extractor
	Ptr<xfeatures2d::SiftDescriptorExtractor> detect =
			xfeatures2d::SIFT::create(maxNFeatures);
	//Extracting features
	//The features will be stored in ds1
	//The output type of ds1 is CV_32F (float)
	detect->detect(src, kp1, cv::Mat());
	detect->compute(src, kp1, ds1);

	resultSize = ds1.rows;
	*nFeatures = resultSize;

	descriptors = (double **)malloc(resultSize* sizeof(*descriptors));
	check_malloc_null(descriptors);

	for (int i = 0; i < resultSize; i++) {
		descriptors[i]  = (double*)malloc(128 * sizeof(double));
		check_malloc_null(descriptors[i]);
		// Set matrix values
		for (int j = 0; j < 128; j++) {
			descriptors[i][j] = ds1.at<float>(i,j);
		}
	}

	return descriptors;
}


/**
 * Calculates the L2-Square distance of the two features: featureA & featureB
 *
 * @param featureA - The first SIFT feature
 * @param featureB - The second SIFT feature
 * @return -1 in case featureA or featureB is NULL, otherwise the L2-Squared distance
 * as given in the assignment instructions
 */
double spL2SquaredDistance(double* featureA, double* featureB)
{
	if (featureA == NULL || featureB == NULL) {
		return -1;
	}
	// Calculate distance
	double dis = 0;
	for (int j = 0 ; j < 128 ; j++)
	{
		double change = (double)(featureA[j] - featureB[j])*(double)(featureA[j] - featureB[j]);
		dis += change;
	}
	return dis;
}


/**
 * Given sift descriptors of the images in the database (databaseFeatures), finds the
 * closest bestNFeatures to a given SIFT feature (featureA). The function returns the
 * INDEXES of the images to which the closest features belong, stored in ascending order
 * (Closest feature image index is first, second closest feature image index is second, etc...).
 * Assumptions:
 *   - Tie break - In case featureA has the same distance (L2Squared distance) from two features,
 *     then the feature that corresponds to the smallest image
 *     index in the database is closer.
 *
 *   - The returned result may contain duplicates in case two features belongs to the same image.
 *
 *   - databaseFeatures is an array of two dimensional arrays, the number of elements
 *     in databaseFeatures is numberOfImages.
 *
 *   - Each entry in databaseFeatures corresponds to the features of some image in the database.
 *     The ith entry corresponds to the features of image_i in the database, and it is a two dimensional
 *     array of dimension nFeaturesPerImage[i]X128.
 *
 *   - The number of descriptors for the ith image is nFeaturesPerImage[i]
 *
 * @param bestNFeatures     - The number of indexes to return.
 * @param featureA          - A sift descriptor which will be compared with the other descriptor
 * 							  (Assumption dimension(bestNFeatures) = 128)
 * @param databaseFeatures  - An array of two dimensional array, in which the descriptors of the images are stored.
 * 							  The ith entry of the array corresponds to the features of the ith image in the database
 * @param numberOfImages    - The number of images in the database. (Number of entries in databaseFeatures)
 * @param nFeaturesPerImage - The number of features for each image. (i.e databaseFeatures[i] is two dimensional
 * 							  array with the dimension nFeaturesPerImage[i]X128
 * @return - NULL if either the following:
 * 			 * featureA is NULL
 * 			 * databaseFeatures is NULL
 * 			 * numberOfImages <= 1
 * 			 * nFeaturesPerImage is NULL
 * 			 * allocation error occurred
 * 			 otherwise, an array of size bestNFeatures is returned such that:
 * 			 * Given that f1, f2, ... the closest features to featureA (i.e d(featureA,f1) <= d(featureA,f2) <= ...)
 * 			 * i1, i2, .... are the indexes of the images to which fi belongs (i.e f1 is a SIFT descriptor of image i1,
 * 			   f2 is a SIFT descriptor of image i2 etc..)
 * 			 Then the array returned is {i1,i2,...,i_bestNFeatures}
 */

int* spBestSIFTL2SquaredDistance(int bestNFeatures, double* featureA,
		double*** databaseFeatures, int numberOfImages,
		int* nFeaturesPerImage)
{
	if (featureA == NULL || databaseFeatures == NULL || numberOfImages <= 1) {
		return NULL;
	}

	// Variables
	int totalNumFeatures = 0;
	int index = 0;
	int * results;

	// Calculate total number of features for later sorting
	for(int i = 0; i < numberOfImages; i++) {
		totalNumFeatures += nFeaturesPerImage[i];
	}

	// create a large list of pairs- distance and image index
	TupleDI * featureList = (TupleDI*)malloc(totalNumFeatures*sizeof(TupleDI));
	check_malloc_null(featureList);

	// for each image
	for(int i = 0; i < numberOfImages; i++) {

		// calculate all the distances of specific photo from featureA
		for (int j = 0; j < nFeaturesPerImage[i]; j++) {
			featureList[index].b = i;
			featureList[index].a = spL2SquaredDistance(featureA, databaseFeatures[i][j]);
			index++;
		}
	}

	// Sort array
	qsort(featureList, totalNumFeatures, sizeof(TupleDI), cmpTupleDI);

	results = (int*)malloc(bestNFeatures*sizeof(int));
	check_malloc_null(results);

	for (int i = 0; i < bestNFeatures; i++) {
		results[i] = featureList[i].b;
	}

	free(featureList);
	return results;
}


